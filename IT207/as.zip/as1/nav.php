
	<div class =assignments">
		<h3> <b> Assignments </b></h3>
		<ul class= "a">
			<li><a href = " http://helios.vse.gmu.edu/~spudi/IT207/as1/">Assignment1 </a></li>
			 
			 
			<li><a href = " http://helios.vse.gmu.edu/~spudi/IT207/as2">Assignment2</a>	</li>
			<li><a href = " http://helios.vse.gmu.edu/~spudi/IT207/as3">Assignment3 </a></li>
			<li><a href = " http://helios.vse.gmu.edu/~spudi/IT207/as4">Assignment4 </a></li>
		</ul>
		<h3> 
		<b>
		Lab Practicum </b> </h3>
		<ul>
		<li> <a href= " http://helios.vse.gmu.edu/~spudi/IT207/pract1"> Practicum1 </a></li>
		<li> <a href= " http://helios.vse.gmu.edu/~spudi/IT207/prac2"> Practicum2 </a></li>
        <b/>
        <a href=" http://helios.vse.gmu.edu/~spudi/IT207/"> Back to home </a>
    </ul>

</div>

