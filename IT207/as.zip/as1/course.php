<div class = "header">
	<div class = "head1">
		<h2>
		
			IT 207 Fall 2018 
		</h2>
		<p> Erhan Uyar <br/>
			George Mason University
		</p>
	</div>

	
	<div class = "head2">
		    <h2>Shubham Pudi </h2>
			<a href="mailto:spudi@masonlive.gmu.edu"></a>
			<?php
			   echo "<p> Last Date modified: ", date("F d Y H:i:s" ,getlastmod()), "EST </p><br/>";
		    ?>
	</div>
</div>
	
