<div class = "footer">
	<div>
		<?php
		echo"<p>
			This website is entirely original work and full academic copyright is retained. Compiles with the Mason Honor Code (http://oai.gmu.edu/mason-honor-code/)</p>";
			?>
			</div>
		</div>